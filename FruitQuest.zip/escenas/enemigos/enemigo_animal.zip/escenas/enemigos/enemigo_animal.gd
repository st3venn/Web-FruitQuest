extends CharacterBody2D

const SPEED = 120
var gravity = ProjectSettings.get_setting("physics/2d/default_gravity")

func _ready():
	velocity.x = SPEED
	$raycast_floor_detection.position.x = 20
	$raycast_wall_detection.target_position.x = 20
	$animaciones.play("run")

func _physics_process(delta):
	if not is_on_floor():
		velocity.y += gravity * delta

	if not $raycast_floor_detection.is_colliding() or $raycast_wall_detection.is_colliding():
		velocity.x *= -1
		$raycast_floor_detection.position.x *= -1
		$raycast_wall_detection.target_position.x *= -1

	$animaciones.flip_h = velocity.x < 0
	move_and_slide()

func _on_damage_zone_body_entered(body):
	if body.is_in_group("player"):
		if body.has_method("takeDamage"):
			body.takeDamage(10)
